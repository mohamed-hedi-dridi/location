<?php

namespace Drupal\forms_steps\Exception;

use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

/**
 * Class AccessDeniedException.
 *
 * @package Drupal\forms_steps\Exception
 */
class AccessDeniedException extends AccessDeniedHttpException {

}
